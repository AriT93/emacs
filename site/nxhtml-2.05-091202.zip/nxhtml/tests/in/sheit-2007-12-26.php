<?php
/**
   *
   * @param string $name
   */
  public function setName($name) {
    $this->name = $name;
  }
?>
