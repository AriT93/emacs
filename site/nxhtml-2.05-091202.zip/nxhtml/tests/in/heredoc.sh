tr a-z A-Z <<EOF


EOF
