<?php
function a()
{
  b($a, $b);
  c($b, $c);
}
?>