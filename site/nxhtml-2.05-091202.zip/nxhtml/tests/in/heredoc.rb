now = Time.now
puts <<-EOF
  It's #{now.hour} o'clock John, where are your kids?
  EOF
now = Time.now
puts <<EOF 
  It's #{now.hour} o'clock John, where are your kids?
EOF
