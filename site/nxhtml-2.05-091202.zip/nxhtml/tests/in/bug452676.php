
<?php

class Foo {
  public $foo = array(
      'long' => <<<'LONG'
lorem ipsum
LONG
);

  public $bar = 1;
 CancelOk
